require("dotenv").config();
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const products = [
  { game: "Mobile Legends", name: "86 Diamonds", sku: "ML-86", price: 20000 },
  { game: "Mobile Legends", name: "172 Diamonds", sku: "ML-172", price: 39000 },
  { game: "Free Fire", name: "70 Diamonds", sku: "FF-70", price: 10000 },
  { game: "Free Fire", name: "140 Diamonds", sku: "FF-140", price: 19000 },
  { game: "PUBG Mobile", name: "60 UC", sku: "PUBG-60", price: 16000 },
  { game: "PUBG Mobile", name: "325 UC", sku: "PUBG-325", price: 79000 }
];

async function main() {
  for (const p of products) {
    await prisma.product.upsert({
      where: { sku: p.sku },
      update: { game: p.game, name: p.name, price: p.price, active: true },
      create: p
    });
  }
  console.log("Seed produk contoh selesai. Verifikasi harga sebelum dipakai.");
}
main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
