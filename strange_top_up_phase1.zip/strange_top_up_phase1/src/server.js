require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { z } = require("zod");
const { PrismaClient } = require("@prisma/client");
const crypto = require("crypto");

const app = express();
const prisma = new PrismaClient();
const port = Number(process.env.PORT || 3000);

app.use(helmet());
app.use(cors({
  origin: (process.env.FRONTEND_ORIGIN || "http://localhost:5500").split(","),
  methods: ["GET", "POST", "PATCH"],
  allowedHeaders: ["Content-Type", "x-admin-key"]
}));
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false }));

const paymentMethods = ["QRIS", "DANA", "OVO"];
const orderSchema = z.object({
  sku: z.string().min(2).max(40),
  playerId: z.string().trim().min(3).max(40),
  serverId: z.string().trim().max(20).optional().or(z.literal("")),
  paymentMethod: z.enum(paymentMethods)
});

function adminOnly(req, res, next) {
  const expected = process.env.ADMIN_API_KEY;
  const supplied = req.header("x-admin-key") || "";
  if (!expected || expected.length < 32) {
    return res.status(503).json({ error: "Admin belum dikonfigurasi dengan aman." });
  }
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Akses admin ditolak." });
  }
  next();
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "STRANGE TOP UP API" }));

app.get("/api/products", async (_req, res, next) => {
  try {
    const products = await prisma.product.findMany({
      where: { active: true },
      select: { id: true, game: true, name: true, sku: true, price: true },
      orderBy: [{ game: "asc" }, { price: "asc" }]
    });
    res.json({ products });
  } catch (e) { next(e); }
});

app.post("/api/orders", async (req, res, next) => {
  try {
    const parsed = orderSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Data pesanan tidak valid.", details: parsed.error.flatten() });

    const product = await prisma.product.findFirst({
      where: { sku: parsed.data.sku, active: true }
    });
    if (!product) return res.status(404).json({ error: "Produk tidak ditemukan atau tidak aktif." });

    const orderCode = "STU-" + crypto.randomBytes(4).toString("hex").toUpperCase();
    const order = await prisma.order.create({
      data: {
        orderCode,
        productId: product.id,
        playerId: parsed.data.playerId,
        serverId: parsed.data.serverId || null,
        amount: product.price,
        paymentMethod: parsed.data.paymentMethod
      },
      select: {
        orderCode: true, amount: true, paymentMethod: true,
        status: true, createdAt: true,
        product: { select: { game: true, name: true } }
      }
    });
    // Status tetap PENDING_PAYMENT sampai payment gateway resmi terintegrasi.
    res.status(201).json({ order, payment: { configured: false, message: "Pembayaran belum diaktifkan. Jangan transfer ke rekening mana pun." } });
  } catch (e) { next(e); }
});

app.get("/api/orders/:code", async (req, res, next) => {
  try {
    const code = String(req.params.code || "").toUpperCase();
    const order = await prisma.order.findUnique({
      where: { orderCode: code },
      select: {
        orderCode: true, amount: true, paymentMethod: true, status: true, createdAt: true,
        product: { select: { game: true, name: true } }
      }
    });
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    res.json({ order });
  } catch (e) { next(e); }
});

app.get("/api/admin/orders", adminOnly, async (_req, res, next) => {
  try {
    const orders = await prisma.order.findMany({
      include: { product: { select: { game: true, name: true } } },
      orderBy: { createdAt: "desc" },
      take: 100
    });
    res.json({ orders });
  } catch (e) { next(e); }
});

app.patch("/api/admin/orders/:code/status", adminOnly, async (req, res, next) => {
  try {
    const schema = z.object({ status: z.enum(["PAID", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED"]) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Status tidak valid." });
    const order = await prisma.order.update({
      where: { orderCode: String(req.params.code).toUpperCase() },
      data: { status: parsed.data.status }
    });
    res.json({ order });
  } catch (e) { next(e); }
});

// Endpoint webhook belum disediakan sampai penyedia pembayaran dipilih.
// Jangan menandai pesanan PAID berdasarkan redirect/screenshot dari pelanggan.

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Terjadi kesalahan pada server." });
});

app.listen(port, () => console.log(`STRANGE TOP UP API berjalan di http://localhost:${port}`));
