# STRANGE TOP UP — Tahap 1 (fondasi backend)

Starter ini menyiapkan API dan database untuk katalog serta pesanan. Pembayaran dan pengiriman produk **belum aktif** karena supplier dan payment gateway belum dipilih.

## Kebutuhan
- Node.js 20 atau lebih baru
- PostgreSQL
- Terminal/command prompt

## Menjalankan secara lokal
1. Instal PostgreSQL dan buat database bernama `strange_top_up`.
2. Salin `.env.example` menjadi `.env`.
3. Isi `DATABASE_URL`, `FRONTEND_ORIGIN`, dan `ADMIN_API_KEY`.
   - Gunakan token acak panjang minimal 32 karakter.
   - Jangan kirim file `.env` atau token ke siapa pun.
4. Jalankan:
   ```bash
   npm install
   npm run db:generate
   npm run db:migrate
   npm run db:seed
   npm run dev
   ```
5. Tes `http://localhost:3000/api/health` dan `http://localhost:3000/api/products`.

## Endpoint tersedia
- `GET /api/health`
- `GET /api/products`
- `POST /api/orders`
  ```json
  {"sku":"ML-86","playerId":"12345678","serverId":"1234","paymentMethod":"QRIS"}
  ```
- `GET /api/orders/STU-XXXXXXXX`
- `GET /api/admin/orders` (header `x-admin-key`)
- `PATCH /api/admin/orders/STU-XXXXXXXX/status` (header `x-admin-key`, body `{"status":"PAID"}`)

## Catatan keamanan dan produksi
- Harga ditentukan server/database, bukan dikirim dari browser.
- Endpoint admin memakai API key untuk tahap pengembangan saja. Sebelum publikasi, ganti dengan login admin individual, password hashing, sesi aman, MFA, dan audit log.
- Tambahkan verifikasi webhook bertanda tangan dari payment gateway. Jangan menganggap pelanggan sudah membayar hanya karena kembali ke halaman sukses atau mengirim screenshot.
- Buat integrasi supplier melalui backend dan gunakan idempotency/reconciliation agar top up tidak terkirim dua kali.
- Jangan menyimpan API key di frontend.
- Produk dan harga seed hanyalah contoh; jangan jual dengan harga tersebut sebelum diverifikasi.
- Perlu kebijakan privasi, syarat layanan, refund, dukungan pelanggan, pencatatan transaksi, dan pemeriksaan persyaratan hukum/merchant.
- Pembukaan akun merchant, domain, hosting, dan kontrak supplier mungkin memerlukan orang dewasa/wali sesuai syarat layanan. Libatkan wali untuk proses yang mensyaratkan usia atau verifikasi identitas.
